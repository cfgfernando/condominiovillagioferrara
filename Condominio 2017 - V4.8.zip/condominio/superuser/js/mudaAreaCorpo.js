$(document).ready(function(){
 
  $("#condominio").click(function(){
    
   $("#mudaArea").load("paginas/condominio.php");
 
   });

});