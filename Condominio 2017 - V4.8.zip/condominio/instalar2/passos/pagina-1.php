<div>
<p style=" font-size:19px; padding-top:20px;"><b>Seja bem vindo ao sistema de instala&ccedil;&atilde;o do seu site.</b></p><br />
Primeiramente, agrade&ccedil;o por ter adquirido o Portal de Condom&iacute;o, assim voc&ecirc; contribuiu com meus estudos e acaba de me dar mais incentivos para continuar criando outros portais.<br />
<br />
Com esta aquisi&ccedil;o voc&ecirc; ter&aacute; <b>1 m&ecirc;s</b> de atualiza&ccedil;&otilde;es e suporte gratis, contados a partir da data de aquisi&ccedil;&atilde;o.<br />
<br />

A princ&iacute;pio, n&atilde;o esque&ccedil;a de criar o banco de dados no seu mysql e efetuar o upload do arquivo <b>"condominio.sql"</b>.<br />
<br />
<div align="center">
<form action="?passo=2" method="post">
<input name="" type="submit" class="btn btn-default" value="Continuar"/>
</form>
</div>
</div>