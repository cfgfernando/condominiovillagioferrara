<?
include_once "passos/mostra_erros.php";
include_once "passos/config.php";
?>
<div style="padding-top:25%;"> <? echo AlertSuccess("PARAB&Eacute;NS!!! TODO O PORTAL FOI INSTALADO COM SUCESSO!!!"); ?>
<? Redireciona("http://".$_SERVER['SERVER_NAME']); ?> </div>


