<?php
error_reporting(E_WARNING);
ini_set("display_errors",0);
?>