<div align="left"><div><h2>Nossa Localidade</h2>
<div height='20' align='center' valign='middle'>
<hr>
</div>
</div>
<p>
<b>Endereço:</b> <?=$endereco_config?>
<br /><b>Bairro:</b> <?=$bairro_config?>
<br /><b>Cidade-UF:</b> <?=$cidade_config?>
<br /><b>CEP:</b> <?=$cep_config?>
<hr />
<p>
<? echo CompletaLinkGoogle($meumapa); ?></p>
</div>