<? $host = 'localhost'; 
$usuario = 'root'; 
$senha = ''; 
$banco= 'condominio'; 
?>