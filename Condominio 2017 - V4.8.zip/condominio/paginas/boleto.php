<script type="text/javascript">

/***********************************************
* Dynamic Ajax Content- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

var loadedobjects=""
var rootdomain="http://"+window.location.hostname

function ajaxpage(url, containerid){
var page_request = false
if (window.XMLHttpRequest) // if Mozilla, Safari etc
page_request = new XMLHttpRequest()
else if (window.ActiveXObject){ // if IE
try {
page_request = new ActiveXObject("Msxml2.XMLHTTP")
} 
catch (e){
try{
page_request = new ActiveXObject("Microsoft.XMLHTTP")
}
catch (e){}
}
}
else
return false
page_request.onreadystatechange=function(){
loadpage(page_request, containerid)
}
page_request.open('GET', url, true)
page_request.send(null)
}

function loadpage(page_request, containerid){
if (page_request.readyState == 4 && (page_request.status==200 || window.location.href.indexOf("http")==-1))
document.getElementById(containerid).innerHTML=page_request.responseText
}

function loadobjs(){
if (!document.getElementById)
return
for (i=0; i<arguments.length; i++){
var file=arguments[i]
var fileref=""
if (loadedobjects.indexOf(file)==-1){ //Check to see if this object has not already been added to page before proceeding
if (file.indexOf(".js")!=-1){ //If object is a js file
fileref=document.createElement('script')
fileref.setAttribute("type","text/javascript");
fileref.setAttribute("src", file);
}
else if (file.indexOf(".css")!=-1){ //If object is a css file
fileref=document.createElement("link")
fileref.setAttribute("rel", "stylesheet");
fileref.setAttribute("type", "text/css");
fileref.setAttribute("href", file);
}
}
if (fileref!=""){
document.getElementsByTagName("head").item(0).appendChild(fileref)
loadedobjects+=file+" " //Remember this object as being already added to page
}
}
}

</script>
<?
$sql_dtmora  = " SELECT * FROM dados_morador WHERE idmorador_dtmora = ".$_SESSION['CD_MORADOR'];
$res_dtmora  = db_query($sql_dtmora);
$rows_dtmora = db_num_rows($res_dtmora);

$sql_dtbnc  = " SELECT * FROM dados_banco ";
$res_dtbnc  = db_query($sql_dtbnc);
$rows_dtbnc = db_num_rows($res_dtbnc); ?>

<? if ($rows_dtmora == 0){
	echo "Sem contas pendentes";
} ?>

<div>

  <? for($i=0; $i<$rows_dtbnc; $i++){ ?>
  <? $count++; ?>
  <? if ($rows_dtmora != 0){ ?>
  <? if (db_result($res_dtbnc,"status_dtbnc",$i) == "1"){ ?>
  <div style="float:left;">
    <div align="center" style="min-width: 120px; margin-left:20px; border-width: 2px; border-style: solid; border-bottom-color:#003333">
      <div align="center" class="bg-primary text-white">
        <?=ucfirst(db_result($res_dtbnc,"banco_dtbnc",$i))?>
      </div>
      <div>&nbsp;</div>
      
      <? for($j=0; $j<$rows_dtmora; $j++){ ?>
      <div> <a href="javascript:ajaxpage('paginas/boleto/index.php?bol=<?=db_result($res_dtbnc,"id_dtbnc",$i)-1?>&mes=<?=ucfirst(db_result($res_dtmora,"mes_dtmora",$j))?>&id=<?=$_SESSION['CD_MORADOR'];?>', 'rightcolumn');" class="btn btn-primary"> <? echo ucfirst(db_result($res_dtmora,"mes_dtmora",$j))."/".db_result($res_dtmora,"ano_dtmora",$j) ?> </a> </div>
      </br>
      <? }  ?>
    </div>
  </div>
  <? } ?>
  <? if ($count == 6){
	$count = 0;
}?>
  <? } 
  } ?>
</div>
<div align="center" style="float:left; padding:0px; margin-left:30px;">
  <div id="rightcolumn"></div>
</div>
<? echo LimpaFloat();?> 